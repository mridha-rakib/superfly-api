// file: src/modules/user/user.route.ts

import upload from "@/config/multer.config";
import { ROLES } from "@/constants/app.constants";
import { authMiddleware } from "@/middlewares/auth.middleware";
import { Router } from "express";
import { UserController } from "./user.controller";

const router = Router();
const userController = new UserController();

router.get("/profile", authMiddleware.verifyToken, userController.getProfile);
router.put(
  "/profile",
  authMiddleware.verifyToken,
  userController.updateProfile,
);

router.post(
  "/profile/photo",
  authMiddleware.verifyToken,
  authMiddleware.authorize(
    ROLES.ADMIN,
    ROLES.SUPER_ADMIN,
    ROLES.CLIENT,
    ROLES.CLEANER,
  ),
  upload.single("photo"),
  userController.uploadProfilePhoto,
);

router.post(
  "/cleaners",
  authMiddleware.verifyToken,
  authMiddleware.authorize(ROLES.ADMIN, ROLES.SUPER_ADMIN),
  userController.createCleaner,
);

router.get(
  "/cleaners",
  authMiddleware.verifyToken,
  authMiddleware.authorize(ROLES.ADMIN, ROLES.SUPER_ADMIN),
  userController.listCleaners,
);

router.get(
  "/cleaners/:cleanerId",
  authMiddleware.verifyToken,
  authMiddleware.authorize(ROLES.ADMIN, ROLES.SUPER_ADMIN),
  userController.getCleaner,
);

router.put(
  "/cleaners/:cleanerId",
  authMiddleware.verifyToken,
  authMiddleware.authorize(ROLES.ADMIN, ROLES.SUPER_ADMIN),
  userController.updateCleaner,
);

router.delete(
  "/cleaners/:cleanerId",
  authMiddleware.verifyToken,
  authMiddleware.authorize(ROLES.ADMIN, ROLES.SUPER_ADMIN),
  userController.deleteCleaner,
);

export default router;
